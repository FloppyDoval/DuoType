import * as React from "react";
import { AvatarStack } from "web-ui";

import type { CardData, ColorPair } from "components/ActiveRetrosPage";

// creating a constant array of users for testing purposes
export const avatarData = [
  {
    id: 0,
    name: "Tester 1",
    picture: undefined,
    username: "tester1",
  },
  {
    id: 1,
    name: "Tester 2",
    picture: "https://images-static.duolingo.cn/avatars/678183694/Na1UnJ2byO",
    username: "tester2",
  },
  {
    id: 2,
    name: "Tester 3",
    picture: "https://images-static.duolingo.cn/avatars/53386295/EVlIP7X41G",
    username: "tester3",
  },
  {
    id: 3,
    name: "Tester 1 With A Very Long Name",
    picture: "https://images-static.duolingo.cn/avatars/1413116/Jq4YQ_VDO9",
    username: "tester4",
  },
  {
    id: 4,
    name: "Tester 5",
    picture: "https://images-static.duolingo.cn/avatars/7878244/bSDiU-pqjs",
    username: "tester5",
  },
  {
    id: 5,
    name: "Tester 6 With A Very Long Name",
    picture: "https://images-static.duolingo.cn/avatars/764630574/lEkNiut71h",
    username: "tester6",
  },
];

// creating a constant array of cardData for testing purposes
export const cardData: CardData[] = [
  {
    date: "mm/dd/yyyy",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. In hac habitasse platea dictumst. Non enim praesent elementum facilisis leo vel fringilla est ullamcorper. Vitae sapien pellentesque habitant morbi tristique senectus et netus et",
    items: ["Item 1", "Item 2", "Item 3", "item4"],
    title:
      "Card 1  Unexpected block statement surrounding arrow body; move the returned value immediately after the `=>`",
  },
  {
    date: "mm/dd/yyyy",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    items: [
      "Item 4 Unexpected block statement surrounding arrow body; move the returned value immediately after the `=>`",
      "Item 5 Unexpected block statement surrounding arrow body; move ",
      "Item 6 Unexpected block statement surrounding arrow body; move ",
    ],
    title: "Card 2",
  },
  {
    date: "mm/dd/yyyy",
    description: "Description 3",
    items: ["Item 7", "Item 8", "Item 9", "item10", "item11"],
    title: "Card 3",
  },
  {
    date: "mm/dd/yyyy",
    description: "Description 4",
    items: ["Item 10", "Item 11", "Item 12"],
    title: "Card 4",
  },
  {
    date: "mm/dd/yyyy",
    description: "Description 5",
    items: ["Item 13", "Item 14", "Item 15"],
    title: "Card 5",
  },
  {
    date: "mm/dd/yyyy",
    description: "Description 5",
    items: ["Item 13", "Item 14", "Item 15"],
    title: "Card 5",
  },
];

export const colorPairs: ColorPair[] = [
  {
    background: "#DDF4FF", // blue
    teamNameColor: "#1CB0F6",
  },
  {
    background: "#D7FFB8", // green
    teamNameColor: "#58CC02",
  },
  {
    background: "#FFF5D3", // yellow
    teamNameColor: "#E7A601",
  },
  {
    background: "#FFDFE0", // red
    teamNameColor: "#FF4B4B",
  },
  {
    background: "#E5E5E5", // grey 1
    teamNameColor: "#777777",
  },
  {
    background: "#ffffe6", // yellow
    teamNameColor: "#cccc00",
  },
  {
    background: "#e6ffff", // cyan(bluish green)
    teamNameColor: "#00cccc",
  },
  {
    background: "#ffe6ff", // purple
    teamNameColor: "#cc00cc",
  },
  {
    background: "#FFE5CC", // orange
    teamNameColor: "#FF6600",
  },
  {
    background: "#FFE6F3", // pink
    teamNameColor: "#FF3399",
  },
  {
    background: "#F2F2F2", // grey 2
    teamNameColor: "#595959",
  },
  {
    background: "#E6FFFF", // teal
    teamNameColor: "#009999",
  },
  {
    background: "#FFEEDD", // brown
    teamNameColor: "#996633",
  },
  {
    background: "#E6E6FF", // lavender
    teamNameColor: "#6666FF",
  },
  {
    background: "#E6FFF7", // turquoise
    teamNameColor: "#009966",
  },
  {
    background: "#FFEBE5", // salmon
    teamNameColor: "#FF5733",
  },
  {
    background: "#F5FFCC", // olive
    teamNameColor: "#99CC00",
  },
  {
    background: "#E5E6FF", // navy
    teamNameColor: "#3333CC",
  },
  {
    background: "#FDEDEC", // coral
    teamNameColor: "#E74C3C",
  },
  {
    background: "#E8F8F5", // light mint
    teamNameColor: "#1ABC9C", // dark mint
  },
  {
    background: "#FAE5D3", // light peach
    teamNameColor: "#E67E22",
  },
  {
    background: "#EBF5FB", // light blue
    teamNameColor: "#3498DB",
  },
  {
    background: "#FEF9E7", // light yellow
    teamNameColor: "#F1C40F",
  },
  {
    background: "#EBF6FF", // light sky blue
    teamNameColor: "#5DADE2",
  },
  {
    background: "#FDFEFE", // light white
    teamNameColor: "#34495E",
  },
  {
    background: "#F9EBEA", // light red
    teamNameColor: "#C0392B",
  },
  {
    background: "#F5EEF8", // light purple
    teamNameColor: "#8E44AD",
  },
  {
    background: "#F6DDCC", // light orange
    teamNameColor: "#D35400",
  },
  {
    background: "#F7E4E4", // light rose
    teamNameColor: "#D11A2A",
  },
  {
    background: "#F3E5F5", // light mauve
    teamNameColor: "#6A1B9A",
  },
  {
    background: "#FFF3E0", // light apricot
    teamNameColor: "#F57C00",
  },
  {
    background: "#FFEBEE", // light ruby
    teamNameColor: "#D32F2F",
  },
  {
    background: "#FFF9E6", // light cream
    teamNameColor: "#F0AD4E",
  },
  {
    background: "#E8F5E9", // light green
    teamNameColor: "#388E3C",
  },
  {
    background: "#F1F8E9", // light lime
    teamNameColor: "#8BC34A",
  },
  {
    background: "#FFF0F5", // light lavender blush
    teamNameColor: "#C71585",
  },
  {
    background: "#F8BBD0", // light pink blush
    teamNameColor: "#E91E63",
  },
  {
    background: "#E0F7FA", // light cyan
    teamNameColor: "#00BCD4",
  },
  {
    background: "#E1F5FE", // light baby blue
    teamNameColor: "#03A9F4",
  },
  {
    background: "#FFF3E0", // light tangerine
    teamNameColor: "#FF9800",
  },
];

// Makes the AvatarStack component

export const renderAvatarStack = () => (
  <AvatarStack
    avatarSize="small"
    className="avatarStack"
    localizer={key => key}
    maxFaceCount={4}
    maxOverflowNamesCount={2}
    users={avatarData}
  />
);
