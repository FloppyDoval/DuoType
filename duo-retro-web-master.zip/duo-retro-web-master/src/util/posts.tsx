export const postData = [
  {
    downvotes: 1,
    text: "I just reached a 100-day streak in Spanish! Just finished the German course. What should I learn next? Just finished the German course. What should I learn next? Just finished the German course. What should I learn next? Just finished the German course. What should I learn next? ext? Just finished the German course. What should I learn next?ext? Just finished the German course. What should I learn next?ext? Just finished the German course. What should I learn next?",
    upvotes: 50,
  },
  {
    downvotes: 5,
    text: "Does anyone have tips for mastering French pronunciation?",
    upvotes: 30,
  },
  {
    downvotes: 2,
    text: "I love the new Duolingo Stories feature. It's so helpful!",
    upvotes: 40,
  },
  {
    downvotes: 3,
    text: "Just finished the German course. What should I learn next?",
    upvotes: 25,
  },
  {
    downvotes: 0,
    text: "The Duolingo podcasts are amazing for listening practice!",
    upvotes: 35,
  },
  {
    downvotes: 1,
    text: "How do you stay motivated to learn every day?",
    upvotes: 20,
  },
  {
    downvotes: 2,
    text: "The reminders from the Duolingo bird are both helpful and funny!",
    upvotes: 45,
  },
  {
    downvotes: 4,
    text: "I earned my first golden owl today! So excited!",
    upvotes: 60,
  },
  {
    downvotes: 3,
    text: "Can someone explain the difference between 'ser' and 'estar' in Spanish?",
    upvotes: 28,
  },
  {
    downvotes: 2,
    text: "Duolingo Plus is worth it for the offline lessons alone.",
    upvotes: 15,
  },
  {
    downvotes: 2,
    text: "I find it difficult to remember vocabulary. Any tips?",
    upvotes: 18,
  },
  {
    downvotes: 1,
    text: "The new update really improved the user experience!",
    upvotes: 33,
  },
  {
    downvotes: 0,
    text: "Is anyone else using Duolingo to prepare for travel?",
    upvotes: 22,
  },
  {
    downvotes: 3,
    text: "I've learned so much more with Duolingo than I ever did in school.",
    upvotes: 37,
  },
  {
    downvotes: 1,
    text: "How long did it take you to complete a language tree?",
    upvotes: 10,
  },
  {
    downvotes: 0,
    text: "I love earning lingots and spending them on fun outfits for Duo!",
    upvotes: 55,
  },
];
