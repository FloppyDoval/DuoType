import type { CardData } from "components/History";

// creating a constant array of users for testing purposes
export const avatarData = [
  {
    id: 0,
    name: "Tester 1",
    picture: undefined,
    username: "tester1",
  },
  {
    id: 1,
    name: "Tester 2",
    picture: "https://images-static.duolingo.cn/avatars/678183694/Na1UnJ2byO",
    username: "tester2",
  },
  {
    id: 2,
    name: "Tester 3",
    picture: "https://images-static.duolingo.cn/avatars/53386295/EVlIP7X41G",
    username: "tester3",
  },
  {
    id: 3,
    name: "Tester 1 With A Very Long Name",
    picture: "https://images-static.duolingo.cn/avatars/1413116/Jq4YQ_VDO9",
    username: "tester4",
  },
  {
    id: 4,
    name: "Tester 5",
    picture: "https://images-static.duolingo.cn/avatars/7878244/bSDiU-pqjs",
    username: "tester5",
  },
  {
    id: 5,
    name: "Tester 6 With A Very Long Name",
    picture: "https://images-static.duolingo.cn/avatars/764630574/lEkNiut71h",
    username: "tester6",
  },
];

// creating a constant array of cardData for testing purposes
export const cardData: CardData[] = [
  {
    date: "mm/dd/yyyy",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. In hac habitasse platea dictumst. Non enim praesent elementum facilisis leo vel fringilla est ullamcorper. Vitae sapien pellentesque habitant morbi tristique senectus et netus et",
    items: ["Item 1", "Item 2", "Item 3", "item4"],
    title:
      "Card 1  Unexpected block statement surrounding arrow body; move the returned value immediately after the `=>`",
  },
  {
    date: "mm/dd/yyyy",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    items: [
      "Item 4 Unexpected block statement surrounding arrow body; move the returned value immediately after the `=>`",
      "Item 5 Unexpected block statement surrounding arrow body; move ",
      "Item 6 Unexpected block statement surrounding arrow body; move ",
    ],
    title: "Card 2",
  },
  {
    date: "mm/dd/yyyy",
    description: "Description 3",
    items: ["Item 7", "Item 8", "Item 9", "item10", "item11"],
    title: "Card 3",
  },
  {
    date: "mm/dd/yyyy",
    description: "Description 4",
    items: ["Item 10", "Item 11", "Item 12"],
    title: "Card 4",
  },
  {
    date: "mm/dd/yyyy",
    description: "Description 5",
    items: ["Item 13", "Item 14", "Item 15"],
    title: "Card 5",
  },
  {
    date: "mm/dd/yyyy",
    description: "Description 5",
    items: ["Item 13", "Item 14", "Item 15"],
    title: "Card 5",
  },
];
