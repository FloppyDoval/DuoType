// Defines a React Hook to read a cookie value and keep track of its changes.

import Cookies from "js-cookie";
import { useEffect, useState } from "react";

export const useCookies = (cookiesName: string) => {
  const [cookiesVal, setCookiesVal] = useState(Cookies.get(cookiesName));

  useEffect(() => {
    const cookiesCheck = () => {
      const currCookiesVal = Cookies.get(cookiesName);
      if (currCookiesVal !== cookiesVal) {
        setCookiesVal(currCookiesVal);
      }
    };

    const interval = setInterval(cookiesCheck, 1);

    return () => {
      clearInterval(interval);
    };
  }, [cookiesName, cookiesVal]);
  return cookiesVal;
};
