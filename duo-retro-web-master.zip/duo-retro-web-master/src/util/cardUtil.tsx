import * as React from "react";
import { useEffect, useState } from "react";
import { Card } from "web-ui";
import { Badge } from "web-ui/juicy";

import styles from "../styles/retroCard.module.scss";
import { colorPairs, renderAvatarStack } from "../util/retrosUtil";
import { fetchRetroData } from "api/client";
import type { RetroItem } from "definitions/retro-card";

const generateRandomLightColor = () => {
  const randomIndex = Math.floor(Math.random() * colorPairs.length);
  return colorPairs[randomIndex];
};

export const useFetchRetroData = () => {
  const [cardData, setCardData] = useState<RetroItem[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data: RetroItem[] = await fetchRetroData();
        setCardData(data);
      } catch (fetchError) {
        setError("Failed to fetch data. Please try again later.");
      }
    };

    fetchData();
  }, []);

  return { cardData, error };
};

export const CardTemplate: React.FC<{ card: RetroItem }> = ({ card }) => {
  const color = generateRandomLightColor();
  return (
    <div>
      <Card
        className={styles["card--content"]}
        onClick={event => {
          if (!(event.target as Element).matches("input[type='checkbox']")) {
            window.location.href = "/more-items-page";
          }
        }}
        role="checkbox"
        style={{ backgroundColor: color.background }}
      >
        <Badge
          className={styles.badge}
          size="small"
          style={{ backgroundColor: color.teamNameColor }}
        >
          Team Name
        </Badge>
        <div className={styles.header}>
          <h1 className={styles.title}>{card.retro_title}</h1>
          <h3 className={styles.date}>{card.date_created}</h3>
        </div>
        <p className={styles.description}>{card.description}</p>
        <h2 className={styles.items}>Action Items</h2>
        <div>
          {card.action_items.map((item: string, index: number) => (
            <li key={index}>
              <span>{item}</span>
            </li>
          ))}
        </div>
        <div className={styles.avatarStack}>{renderAvatarStack()}</div>
      </Card>
    </div>
  );
};
