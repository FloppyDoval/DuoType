// declarations.d.ts

declare module "*.svg"; // Added to allow svg imports
