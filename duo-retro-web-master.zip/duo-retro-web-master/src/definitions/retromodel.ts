export interface Retro {
  retro_title: string;
  team_name: string;
  description: string;
  date_created?: string;
  resources?: string[];
  admins: UserID[];
  participants: UserID[];
  retro_state: RetroState;
  invites?: Invites;
  posts?: PostItems;
  action_items?: ActionItems;
}
export interface UserID {
  user_id: string;
}
export enum RetroStateOptions {
  ENTRY = "entry",
  LOBBY = "lobby",
  REFLECTION = "reflection",
  ACTION_ITEMS = "action_items",
  CLOSED = "closed",
}
export interface RetroState {
  retro_state: RetroStateOptions;
}
export enum InviteStatus {
  ACCEPT = "accepted",
  PENDING = "maybe",
  DECLINE = "declined",
}
export interface Invites {
  invitees: Record<string, InviteStatus>;
}
export interface PostID {
  post_id: string;
}
export interface PostContent {
  content: string;
}
export interface PostItems {
  posts: Record<string, [UserID, PostContent, boolean]>;
}
export interface ActionItemID {
  action_item_id: string;
}
export interface ActionItemContent {
  action_item_content: string;
}
export interface ActionItems {
  action_items: Record<string, [ActionItemContent, UserID[]]>;
}
