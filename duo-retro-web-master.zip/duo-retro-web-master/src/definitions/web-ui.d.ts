declare namespace WebUi {
  export type ExtendedColor = unknown;
}
