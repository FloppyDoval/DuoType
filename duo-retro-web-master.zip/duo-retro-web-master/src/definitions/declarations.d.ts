declare module "*.svg";
