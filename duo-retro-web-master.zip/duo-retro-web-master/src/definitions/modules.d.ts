declare module "images/*";
declare module "lottie/*";
declare module "*.module.scss";
