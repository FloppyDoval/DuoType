export declare namespace Monolith {
  export interface User {
    email?: string;
    roles?: string[];
    username?: string;
    picture: string;
    name: string;
  }
}
