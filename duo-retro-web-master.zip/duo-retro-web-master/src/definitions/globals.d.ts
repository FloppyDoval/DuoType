// for later backend connection. Stores the backend origin in the environment variable REACT_APP_BACKEND_ORIGIN.
declare let process: {
  env: {
    API?: string;
    DUOLINGO_JWT?: string;
    EXCESS_MODE: "debug" | "production";
    NODE_ENV: "development" | "production";
  };
};
