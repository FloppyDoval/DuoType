interface User {
  user_id: number;
  user_name: string;
  email: string;
}

export interface RetroItem {
  retro_id: number;
  retro_title: string;
  date_created: string;
  author_id: string;
  author_name: string;
  team_id: number;
  team_name: string;
  user: User;
  description: string;
  action_items: string[];
  members: User[];
  updated_at: string;
}
