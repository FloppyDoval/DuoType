import * as React from "react";
import { Link } from "react-router-dom";
import { Avatar } from "web-ui/juicy";

import "web-ui/styles/fonts.scss";
import { getLoggedIn } from "api/user";
import type { Monolith } from "definitions/monolith";
import duoRetropng from "images/duoRetro.png";
import styles from "styles/NavBar.module.scss";
import { useCookies } from "util/useCookies";

// conditionally render the user name and avatar only if the user is logged in
const FetchUser = () => {
  const [user, setUser] = React.useState<Monolith.User | null>(null);
  React.useEffect(() => {
    getLoggedIn().then(setUser);
  }, []);
  const userCookies = useCookies("jwt_token");
  const [isLoggedIn, setIsLoggedIn] = React.useState(Boolean(userCookies));
  React.useEffect(() => {
    setIsLoggedIn(Boolean(userCookies));
  }, [userCookies]);
  if (isLoggedIn) {
    return (
      <div>
        <Link
          className={styles.userData}
          to={`https://www.duolingo.com/diagnostics/user/summary/${user?.email}`}
        >
          {`${user?.name}`}
          <Avatar size="large" src={`${user?.picture}/medium`} />
        </Link>
      </div>
    );
  } else {
    return null;
  }
};

const Header = () => (
  <div className={styles.header}>
    <a href="/">
      {" "}
      <img alt="logo" className={styles.logoImage} src={duoRetropng} />{" "}
    </a>
    <div>
      <FetchUser />
    </div>
  </div>
);

export default Header;
