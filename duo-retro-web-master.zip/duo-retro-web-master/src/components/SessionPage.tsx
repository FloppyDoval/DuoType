/**
 * This is the home page.
 * Currently displays options to create a new retro or join an existing retro(Both lead to a dummy page).
 * Will display a list of active/history retros soon.
 */
import * as React from "react";
import { useNavigate } from "react-router-dom";
import { GradingButton } from "web-ui/juicy";

import { loadUserInfo } from "api/user";
import ComputerDuo from "images/ComputerDuo.svg";
import CurvySvg from "images/Curvy.svg";
import duoChalkboard from "images/Duo_Chalkboard.svg";
import GroupSvg from "images/Group.svg";
import styles from "styles/SessionPage.module.scss";
import { useAppDispatch } from "util/hooks";
import { useCookies } from "util/useCookies";

import ActiveRetro from "./ActiveRetrosPage";
import History from "./History";

const NavigationButton = ({
  path,
  children,
}: {
  path: string;
  children: React.ReactNode;
}) => {
  const navigate = useNavigate();
  const handleClick = () => {
    navigate(path);
  };
  return (
    <GradingButton
      className={styles.clickButton}
      onClick={handleClick}
      state="enabled"
      type="button"
      variant="correct"
    >
      {children}
    </GradingButton>
  );
};

const WelcomeMessage = () => (
  <div>
    <div className={styles.welcomeMessage}>
      <div className={styles.slogan}>
        <h2>
          One For All, <br />
          All for One
        </h2>
        <img alt="Group" className={styles.groupImage} src={GroupSvg} />
      </div>
      <div>
        <h2 className={styles.description}>
          Share feedback and learn from recently completed work. Find
          opportunities to be more effective in the way we work and be more
          productive with the time we have.
        </h2>
      </div>
    </div>
    <img src={CurvySvg} />
  </div>
);

const CreateorJoin = () => (
  <div className={styles.containerOfOptions}>
    <div className={styles.box}>
      <img alt="chok" className={styles.boxImage} src={duoChalkboard} />
      <h3 className={styles.createRetroHeader}> Join a retrospective </h3>
      <div className={styles.createBoxContents}>
        Find opportunities to be more effective in the way we work and be more
        productive with the time we have.
      </div>
      <NavigationButton path="/active">JOIN</NavigationButton>
    </div>

    <div className={styles.box}>
      <img alt="chok" className={styles.boxImage} src={ComputerDuo} />
      <h3 className={styles.joinRetroHeader}> New Reflections </h3>
      <div className={styles.joinBoxContents}>
        Participate in a retrospective from your a team or project around the
        company
      </div>
      <NavigationButton path="/newretro">CREATE</NavigationButton>
    </div>
  </div>
);

const SessionPage = () => {
  const dispatch = useAppDispatch();
  React.useEffect(() => {
    dispatch(loadUserInfo());
  }, [dispatch]);

  const navigate = useNavigate();
  const userCookies = useCookies("jwt_token");
  const [isLoggedIn, setIsLoggedIn] = React.useState(Boolean(userCookies));

  const showLoginOrNot = React.useCallback(() => {
    if (isLoggedIn) {
      navigate("/");
    } else {
      navigate("/login");
    }
  }, [isLoggedIn, navigate]);

  React.useEffect(() => {
    setIsLoggedIn(Boolean(userCookies));
  }, [userCookies]);

  React.useEffect(() => {
    showLoginOrNot();
  }, [showLoginOrNot]);

  return (
    <div className={styles.homePageElements}>
      <WelcomeMessage />
      <CreateorJoin />
      <ActiveRetro />
      <History />
    </div>
  );
};

export default SessionPage;
