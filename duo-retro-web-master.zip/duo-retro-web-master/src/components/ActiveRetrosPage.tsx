import * as React from "react";

import styles from "../styles/ActiveRetrosCard.module.scss";
import { CardTemplate } from "util/cardUtil";
import { useFetchRetroData } from "util/cardUtil";

// Defines the interface for card data

export interface CardData {
  date: string;
  description: string;
  items: string[];
  title: string;
}

export interface ColorPair {
  background: string;
  teamNameColor: string;
}

// Defines the ActiveRetro component

const ActiveRetro: React.FC = () => {
  const { cardData, error } = useFetchRetroData();
  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className={styles["active--retro--section"]}>
      <div className={styles["active--header"]}>Past Retrospectives</div>
      <div className={styles["card"]}>
        {cardData.map((card, index) => (
          // Renders the CardTemplate component for each card in the cardData array
          <CardTemplate card={card} key={index} />
        ))}
      </div>
    </div>
  );
};

export default ActiveRetro;
