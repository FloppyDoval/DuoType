import * as React from "react";

import styles from "styles/ActionPageFooter.module.scss";

// Defines the ActionPageFooter component
const ActionPageFooter: React.FC = () => (
  <div className={styles.footer}>
    <button className={styles.postButton}>ASSIGNEE(S)</button>
    <textarea
      className={styles.textarea}
      placeholder="Type an action item here..."
    />
    <button className={styles.postButton}>POST ACTION</button>
  </div>
);

export default ActionPageFooter;
