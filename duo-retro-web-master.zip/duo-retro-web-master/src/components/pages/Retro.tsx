import React from "react";
import { useParams } from "react-router-dom";

import styles from "styles/Retro.module.scss";

const Retro = () => {
  const { retroID } = useParams<{ retroID: string }>();
  return (
    <div className={styles.text}>
      <p> The Retro ID is {retroID}</p>
    </div>
  );
};
export default Retro;
