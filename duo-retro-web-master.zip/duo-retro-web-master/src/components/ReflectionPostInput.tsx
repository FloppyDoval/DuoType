import * as React from "react";
import { Button } from "web-ui/juicy"; // Import the Button component
import { TextArea } from "web-ui/juicy";

import styles from "styles/ReflectionPage.module.scss";

interface ReflectionFooterProps {
  textAreaValue: string;
  handleTextAreaChange: (event: React.ChangeEvent<HTMLTextAreaElement>) => void;
  handlePostClick: () => void;
}

const ReflectionFooter: React.FC<ReflectionFooterProps> = ({
  textAreaValue,
  handleTextAreaChange,
  handlePostClick,
}) => {
  const renderTextArea = (
    value: string,
    onChange: (event: React.ChangeEvent<HTMLTextAreaElement>) => void,
  ) => (
    <TextArea
      className={styles["text-area"]}
      onChange={onChange}
      placeholder="Type your thoughts here..."
      rows={5}
      state="enabled"
      value={value}
    />
  );

  const renderPostButton = (onClick: () => void) => (
    <Button
      className={styles["post-button"]}
      onClick={onClick}
      size="large"
      state="enabled"
      variant="primary"
    >
      Post
    </Button>
  );

  return (
    <div className={styles["footer"]}>
      <div className={styles["text-area-wrapper"]}>
        {renderTextArea(textAreaValue, handleTextAreaChange)}
      </div>
      {renderPostButton(handlePostClick)}
    </div>
  );
};

export default ReflectionFooter;
