import * as React from "react";
import { useState } from "react";
import { Card } from "web-ui";
import { Avatar } from "web-ui/juicy";

import type { PostData } from "components/ReflectionPage";
import favicon from "images/favicon.ico";
import styles from "styles/ReflectionPage.module.scss";

const renderAvatar = () => (
  <Avatar
    onClick={() => {
      window.location.href = "https://www.duolingo.com/";
    }}
    size="medium"
    src={favicon}
  />
);

export const PostTemplate: React.FC<{ post: PostData }> = ({ post }) => {
  const initialVoteCount =
    post.upvotes >= post.downvotes ? post.upvotes - post.downvotes : 0;
  const [voteCount, setVoteCount] = useState(initialVoteCount);

  const handleUpvote = (e: React.MouseEvent) => {
    e.stopPropagation();
    setVoteCount(voteCount + 1);
  };

  const handleDownvote = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (voteCount > 0) {
      setVoteCount(voteCount - 1);
    }
  };

  return (
    <div>
      <Card className={styles["reflection-post-card"]} role="checkbox">
        <div className={styles["post-item-text"]}>{post.text}</div>
        <div className={styles.userAvatar}>{renderAvatar()}</div>
        <div className={styles["post-actions"]}>
          <div className={styles.arrows}>
            <button className={styles["upvote"]} onClick={handleUpvote}>
              {"\u{1F44D}"}
            </button>
            <div className={styles["vote-count"]}>{voteCount}</div>
            <button className={styles["downvote"]} onClick={handleDownvote}>
              {"\u{1F44E}"}
            </button>
          </div>
          <div className={styles["comment-wrapper"]}>
            <button
              className={styles.comment}
              onClick={e => e.stopPropagation()}
            >
              {"\u{1F4AC}"}
            </button>
            <div className={styles["comment-count"]}>100</div>
          </div>
        </div>
      </Card>
    </div>
  );
};
