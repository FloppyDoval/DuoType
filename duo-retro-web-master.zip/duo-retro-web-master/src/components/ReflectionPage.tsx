import * as React from "react";
import { useState } from "react";

import { PostTemplate } from "components/ReflectionPost";
import duoIdeas from "images/duoIdeas.svg";
import styles from "styles/ReflectionPage.module.scss";

import ReflectionFooter from "./ReflectionPostInput";

export interface PostData {
  comments: string[];
  downvotes: number;
  text: string;
  upvotes: number;
}

const ReflectionPage: React.FC = () => {
  const [postData, setPostData] = useState<PostData[]>([]); // Initialize local state with imported postData
  const [textAreaValue, setTextAreaValue] = useState("");

  const handleTextAreaChange = (
    event: React.ChangeEvent<HTMLTextAreaElement>,
  ) => {
    setTextAreaValue(event.target.value);
  };

  const handlePostClick = () => {
    if (textAreaValue.trim() !== "") {
      setPostData([
        ...postData,
        {
          comments: [],
          downvotes: 0,
          text: textAreaValue,
          upvotes: 0,
        },
      ]);
      setTextAreaValue(""); // Clears the text area after posting
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles["retro-title"]}>
        <h1>Title of Retro</h1>
      </div>
      <div className={styles["cards"]}>
        {postData.map((samplePost, index) => (
          <PostTemplate key={index} post={samplePost} />
        ))}
        <div className={styles.duoBird}>
          <img alt="Duo bird with bulb at its head" src={duoIdeas} />
        </div>
      </div>
      <ReflectionFooter
        handlePostClick={handlePostClick}
        handleTextAreaChange={handleTextAreaChange}
        textAreaValue={textAreaValue}
      />
    </div>
  );
};

export default ReflectionPage;
