import * as React from "react";

import styles from "../styles/HistoryCard.module.scss";
import { CardTemplate } from "util/cardUtil";
import { useFetchRetroData } from "util/cardUtil";
// Defines the interface for card data

export interface CardData {
  date: string;
  description: string;
  items: string[];
  title: string;
}

// Defines the History component
const History: React.FC = () => {
  const { cardData, error } = useFetchRetroData();
  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div className={styles["history--retro--section"]}>
      <div className={styles["history--header"]}>Past Retrospectives</div>
      <div className={styles["card"]}>
        {cardData.map((card, index) => (
          // Renders the CardTemplate component for each card in the cardData array
          <CardTemplate card={card} key={index} />
        ))}
      </div>
    </div>
  );
};

export default History;
