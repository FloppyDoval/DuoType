import { useState } from "react";
import * as React from "react";

import GroupRetros from "../images/GroupRetro.svg";
import styles from "../styles/NewRetroPage.module.scss";

const NewRetroPage = () => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [team, setTeam] = useState("");

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (title && description && team) {
      const formData = {
        description,
        team,
        title,
      };

      localStorage.setItem("retro", JSON.stringify(formData));
      window.location.href = "/lobby";
    }
  };

  return (
    <form className={styles.wrap} onSubmit={handleSubmit}>
      <img alt="Group" className={styles.imageContainer} src={GroupRetros} />{" "}
      <div className={styles.inputGroup}>
        <input
          className={styles.title}
          onChange={e => setTitle(e.target.value)}
          placeholder="Title"
          required={true}
          type="text"
          value={title}
        />
        <input
          className={styles.description}
          onChange={e => setDescription(e.target.value)}
          placeholder="Description"
          required={true}
          type="text"
          value={description}
        />
        <input
          className={styles.team}
          onChange={e => setTeam(e.target.value)}
          placeholder="Team"
          required={true}
          type="text"
          value={team}
        />
        <label className={styles.files} htmlFor="fileInput">
          <input
            id="fileInput"
            multiple={true}
            style={{ display: "none" }}
            type="file"
          />
          <div>DRAG AND DROP ANY FILES</div>
        </label>
        <div className={styles.buttonContainer}>
          <button className={styles.cont_button} type="submit">
            CONTINUE
          </button>
        </div>
      </div>
    </form>
  );
};

export default NewRetroPage;
