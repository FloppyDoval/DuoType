import * as React from "react";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

import GroupSvg from "../images/Group.svg";
import styles from "../styles/LoginPage.module.scss";
import { useCookies } from "util/useCookies";

const LoginPage = () => {
  const navigate = useNavigate();
  const userCookies = useCookies("jwt_token");

  useEffect(() => {
    if (userCookies) {
      navigate("/");
    }
  }, [userCookies, navigate]);

  return (
    <div>
      <div className={styles.slogan}>
        <h2>
          One For All, <br />
          All for One
        </h2>
        <img alt="Group" className={styles.groupImage} src={GroupSvg} />{" "}
      </div>
      <div>
        <h2 className={styles.description}>
          Share feedback and learn from recently completed work. Find
          opportunities to be more effective in the way we work and be more
          productive with the time we have.
        </h2>
      </div>
      <div>
        <button
          className={styles.loginbutton}
          onClick={() => window.open("https://duolingo.com", "_blank")}
        >
          Login TO BEGIN
        </button>
      </div>
    </div>
  );
};

export default LoginPage;
