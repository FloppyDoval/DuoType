/**
 * This is the simple App component for the application.
 * It currently displays a simple greeting message. Will be updated later
 */
import * as React from "react";
const App = () => (
  <div>
    <h1>Hello, this is the app page</h1>
  </div>
);

export default App;
