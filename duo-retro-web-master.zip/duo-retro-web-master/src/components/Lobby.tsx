// Lobby to double check the retro Information provided by the user before creation
// Fetches the data inputed by the user from localstorage
// TODO: Will display the participants avatar once backend is ready.
import React from "react";

import StaringDuo from "../images/StaringDuo.svg";
import styles from "../styles/Lobby.module.scss";

const Lobby = () => {
  const formData = JSON.parse(localStorage.getItem("retro") ?? "{}");

  const confirmationPopUp = () => {
    if (window.confirm("Has everyone joined the retro?")) {
      window.location.href = "/retroID"; // Redirect to the retro page (defined later)
    }
  };

  return (
    <div className={styles.page}>
      <img alt="Group" className={styles.imageContainer} src={StaringDuo} />
      <div className={styles.summary}>
        <div className={styles.retroTitle}>{formData.title}</div>
        <div className={styles.retroTeamBox}>
          <div className={styles.retroTeam}>{formData.team}</div>
        </div>
        <div className={styles.retroDescription}>{formData.description}</div>
        <button className={styles.shareButton} onClick={confirmationPopUp}>
          Start!
        </button>
      </div>
    </div>
  );
};

export default Lobby;
