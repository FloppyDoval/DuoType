import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";

import type { RootState } from "../../redux/store";
import type { Monolith } from "definitions/monolith";

interface UserState {
  user: Monolith.User | undefined;
}

const initialState: UserState = {
  user: undefined,
};

export const userSlice = createSlice({
  initialState,
  name: "user",
  reducers: {
    setUser: (state, action: PayloadAction<Monolith.User>) => {
      state.user = action.payload;
    },
  },
});

export const userSelector = (state: RootState) => state.user;

export default userSlice.reducer;
