import "normalize.css";
import "web-ui/styles/fonts.scss";

import * as React from "react";
import { createRoot } from "react-dom/client";
import { Provider } from "react-redux";
import { BrowserRouter, Route, Routes } from "react-router-dom";

import "images/favicon.ico";
import "styles/index.module.scss";
import ActiveRetrosPage from "components/ActiveRetrosPage";
import History from "components/History";
import Lobby from "components/Lobby";
import LoginPage from "components/LoginPage";
import Header from "components/NavBar";
import NewRetroPage from "components/NewRetroPage";
import ReflectionPage from "components/ReflectionPage";
import SessionPage from "components/SessionPage";
import ActionPage from "components/actionPageFooter";
import Retro from "components/pages/Retro";
import store from "redux/store";

const AppWithRouter = () => (
  <Provider store={store}>
    <BrowserRouter>
      <Header />
      <Routes>
        <Route element={<SessionPage />} path="/" />
        <Route element={<ActiveRetrosPage />} path="/active" />
        <Route element={<LoginPage />} path="/login" />
        <Route element={<NewRetroPage />} path="/newRetro" />
        <Route element={<History />} path="/history" />
        <Route element={<ReflectionPage />} path="/reflection" />
        <Route element={<Lobby />} path="/lobby" />
        <Route element={<ActionPage />} path="/action" />
        <Route element={<Retro />} path="/retro/:retroId" />
      </Routes>
    </BrowserRouter>
  </Provider>
);

const root = createRoot(document.getElementById("root") as HTMLElement);
root.render(<AppWithRouter />);
