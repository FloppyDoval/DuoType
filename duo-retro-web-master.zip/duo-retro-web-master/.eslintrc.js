module.exports = {
  extends: ["duolingo"],
  parserOptions: {
    project: "tsconfig.eslint.json",
  },
  rules: {
    "react/jsx-no-literals": "off",
    "@typescript-eslint/no-duplicate-imports": "off",
    "@typescript-eslint/naming-convention": [
      "error",
      {
        // Allow global configuration variables, like __DESKTOP_MIN_WIDTH__
        selector: ["objectLiteralProperty", "variable"],
        format: ["UPPER_CASE"],
        filter: "^__.*__",
        leadingUnderscore: "requireDouble",
        trailingUnderscore: "requireDouble",
      },
      {
        // TODO (joel-duolingo): remove once all deprecated React components are upgraded
        selector: "classMethod",
        filter: "^UNSAFE_",
        format: null,
      },
      {
        // Allow dangerouslySetInnerHTML's __html object
        selector: "objectLiteralProperty",
        filter: "^__html$",
        format: null,
      },
      {
        // Allow our translation function
        selector: "variable",
        filter: "^_i(Text)?$",
        format: null,
      },
      {
        // Allow the original names for destructured variables
        selector: ["variable", "function", "parameter"],
        modifiers: ["destructured"],
        format: null,
      },
      {
        selector: "objectLiteralProperty",
        modifiers: ["requiresQuotes"],
        format: null,
      },
      {
        selector: ["variable", "function"],
        format: ["camelCase", "PascalCase", "UPPER_CASE"],
      },
      {
        selector: "enumMember",
        format: ["PascalCase", "UPPER_CASE"],
      },
      {
        selector: ["objectLiteralProperty", "typeProperty"],
        format: ["camelCase", "PascalCase", "snake_case", "UPPER_CASE"],
      },
      {
        selector: "typeLike",
        format: ["PascalCase"],
      },
      {
        // Allow standard underscore import format
        selector: "import",
        filter: "^_$",
        format: null,
      },
      {
        selector: "import",
        format: ["camelCase", "PascalCase", "UPPER_CASE"],
      },
      {
        selector: "default",
        format: ["camelCase"],
        leadingUnderscore: "allow",
        trailingUnderscore: "allow",
      },
    ],
  },
};
