[![Overall](https://img.shields.io/endpoint?style=flat&url=https%3A%2F%2Fapp.opslevel.com%2Fapi%2Fservice_level%2FxHfowbsDy7GzGD2GB3EaQ-j6ZpEvOaMek3fVvtuPtEs)](https://app.opslevel.com/services/duo-retro-web/maturity-report)

# DuoRetro Web

Web frontend for the 2024 Thrive internship project DuoRetro. Link to spec: [here](https://docs.google.com/document/d/1u95qUBnrLvr4tH3mSDusAEEUiUrwut6VCrdg52N39F0/edit).

<h3>Team Members + Goals </h3>

<a href="https://duolingo.pingboard.com/users/11898515">Hala</a>'s goal: having fun!

<a href="https://duolingo.pingboard.com/users/11898514">Gabbi</a>'s goal: increased confidence with coding

<a href = "https://duolingo.pingboard.com/users/11898513"> Floppy</a>'s goal: enjoy myself and feel more conident with coding! :)

<a href = "https://duolingo.pingboard.com/users/11898526"> Maxwell</a>'s goal: having a great time!

## Usage

1. Run `make` to start the local server at http://localhost:3000.

## Running Tests

1. Run `make test` to start an interactive Jest session.

## Using Colors

To use a dynamic color in CSS:

```scss
.text {
  color: duo-color("macaw");
}
```

## Other Tasks

See Makefile for other tasks.
